<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Nota;

class NotaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $notas = Nota::paginate(10);
        return view('notasIndex') ->with('notas', $notas);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('formularioNota');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'titulo'=>'required|max:50',
            'descripcion'=>'required|max:50',
            'categoria'=>'required',
        ]);
        //dd($request);
        //VALIDAR TODO
        //CREAR UN NUEVO PRODUCTO
        $nuevaNota = new Nota();
        
        //ASIGNAMOS VALORES
        $nuevaNota->titulo = $request->input('titulo');
        $nuevaNota->descripcion = $request->input('descripcion');
        $nuevaNota->categoria_id = $request->input('categoria_id');
        //$usuario->password = Hash::make($request->input('password'));
        
        //GUARDAMOS
        $creado = $nuevaNota->save();

        if ($creado) {
            return redirect()->route('nota.index')->with('mensaje', 'La nota '.$nota->titulo.' se guardo exitosamente');

        } else {
            //Retornar mensaje de error
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $nota = Nota::findOrFail($id);
        return view('NotaIndividual')->with('nota', $nota);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $nota=nota::findorFail($id);
        return view('formularioNota')->with('nota', $nota);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'Titulo'=>'required|max:50',
            'Descripcion'=>'required|max:50',
            'categoria'=>'required',
        ]);
        
        $nota= Nota::findorFail($id);
        //hacer los cambios
        $nota->titulo= $request->input('titulo');
        $nota->descripcion= $request->input('descripcion');
        $nota->categoria_id= $request->input('categoria_id');
        
        //redirigir
        return redirect()->route('notas.index')
            ->with('success', 'Nota actualizada exitosamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $borrados= Nota::destroy($id);

        if($borrados>=1){
            return redirect()->route('notas.index')-with('mensaje','La nota fue eliminada');
        } else {
            return redirect()->route('notas.index')-with('mensaje','La nota no fue eliminada');
        }
    }
}