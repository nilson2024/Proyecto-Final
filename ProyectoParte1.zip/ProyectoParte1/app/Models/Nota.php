<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Categoria;

class Nota extends Model
{
    use HasFactory;
    public function Categoria(){
        return $this->BelongsTo(Categoria::class);
    }
}
