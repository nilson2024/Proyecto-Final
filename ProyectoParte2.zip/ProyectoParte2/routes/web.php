<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/', function () {
    return view('notasIndex');
});

Route::prefix('/notas')->group(function () {

   
    Route::get('/', [NotaController::class, 'index'])->name('notas.index')->middleware('auth');

    Route::get('/mostrar/{id}', [NotaController::class, 'show'])->name('nota.show')->whereNumber('id', '[0-9]+')->middleware('auth');
    
    Route::get('/crear', [NotaController::class, 'create'])->name('nota.create')->middleware('auth');
    Route::get('/crear', [NotaController::class, 'store'])->name('nota.store')->middleware('auth');
    
    Route::get('/{id}/editar', [NotaController::class, 'edit'])->name('nota.edit')->whereNumber('id', '[0-9]+')->middleware('auth');
    Route::put('/{id}/editar', [NotaController::class, 'update'])->name('nota.update')->whereNumber('id', '[0-9]+')->middleware('auth');
    
    Route::delete('/{id}/borrar', [NotaController::class, 'destroy'])->name('nota.destroy')->whereNumber('id', '[0-9]+')->middleware('auth');

  
});
require __DIR__.'/auth.php';
