@extends('plantillas.plantilla')
@section('titulo', 'Formulario de Nota')
@section('contenido')
<h1>Formulario Nota</h1>
<form action="{{ isset($nota) ? route('nota.update', ['id' => $nota->id]) : route('nota.store') }}" method="post">
  @csrf
<div class="mb-3">
  <label for="Titulo" class="form-label">Titulo</label>
  <input type="text" name= "titulo" class="form-control" id="titulo" placeholder="Titulo" value="{{ isset($nota) ? $nota->titulo : old('titulo') }}">
</div>
<div class="mb-3">
  <label for="Descripcion" class="form-label">Descripcion</label>
  <input type="text" name= "descripcion" class="form-control" id="descripcion" placeholder="Escribe aqui" value="{{ isset($nota) ? $nota->descripcion : old('descripcion') }}">>
</div>
<div class="mb-3">
  <label for="categoria" class="form-label">Categoria</label>
  <select name="opciones" value="{{ isset($nota) ? $nota->nombre : old('nombre') }}">>
    @foreach($categorias as $categoria => $nombre)
        <option value="{{ $nombre }}">{{ $nombre }}</option>
    @endforeach
</select>
</div>
<input type="submit" value="{{ isset($nota) ? 'Actualizar' : 'Guardar' }}" class="btn btn-primary">
<input type="reset" value="Limpiar" class="btn btn-danger">
</form>
@endsection