@extends('plantillas.plantilla')
@section('titulo', 'Nota')
@section('contenido')

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">{{ $nota->titulo }}</h5>
    <h6 class="card-subtitle mb-2 text-body-secondary">{{ $nota->descripcion }}</h6>
    <h6 class="card-subtitle mb-2 text-body-secondary">{{ $nota->categoria_id }}</h6>
    <p class="card-text">La nota {{ $nota->created_at }} y modificada por ultima vez {{ $nota->updated_at }}.</p>
    <a href="{{ route('nota.edit', , ['id'=>$nota->id]) }}" class="card-link">Editar</a>
    <a href="{{ url()->previous() }}" class="card-link">Regresar</a>
  </div>
</div>

@endsection